<?php

namespace Trexz\Http\Requests\Api\Application\Locations;

class GetLocationRequest extends GetLocationsRequest
{
}
