<?php

namespace Trexz\Events;

abstract class Event
{
}
