<?php

namespace Trexz\Exceptions\Service\Schedule\Task;

use Trexz\Exceptions\DisplayException;

class TaskIntervalTooLongException extends DisplayException
{
}
