<?php

namespace Trexz\Exceptions\Service\Allocation;

use Trexz\Exceptions\PterodactylException;

class AllocationDoesNotBelongToServerException extends PterodactylException
{
}
