<?php

namespace Trexz\Exceptions\Service\Allocation;

use Trexz\Exceptions\DisplayException;

class ServerUsingAllocationException extends DisplayException
{
}
