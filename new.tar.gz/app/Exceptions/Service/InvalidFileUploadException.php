<?php

namespace Trexz\Exceptions\Service;

use Trexz\Exceptions\DisplayException;

class InvalidFileUploadException extends DisplayException
{
}
