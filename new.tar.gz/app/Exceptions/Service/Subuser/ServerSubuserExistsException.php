<?php

namespace Trexz\Exceptions\Service\Subuser;

use Trexz\Exceptions\DisplayException;

class ServerSubuserExistsException extends DisplayException
{
}
