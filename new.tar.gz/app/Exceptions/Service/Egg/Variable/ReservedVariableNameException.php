<?php

namespace Trexz\Exceptions\Service\Egg\Variable;

use Trexz\Exceptions\DisplayException;

class ReservedVariableNameException extends DisplayException
{
}
