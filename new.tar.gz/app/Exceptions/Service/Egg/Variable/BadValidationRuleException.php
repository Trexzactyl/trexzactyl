<?php

namespace Trexz\Exceptions\Service\Egg\Variable;

use Trexz\Exceptions\DisplayException;

class BadValidationRuleException extends DisplayException
{
}
