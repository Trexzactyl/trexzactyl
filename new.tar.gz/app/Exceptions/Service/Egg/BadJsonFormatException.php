<?php

namespace Trexz\Exceptions\Service\Egg;

use Trexz\Exceptions\DisplayException;

class BadJsonFormatException extends DisplayException
{
}
