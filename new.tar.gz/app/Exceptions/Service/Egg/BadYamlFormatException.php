<?php

namespace Trexz\Exceptions\Service\Egg;

use Trexz\Exceptions\DisplayException;

class BadYamlFormatException extends DisplayException
{
}
