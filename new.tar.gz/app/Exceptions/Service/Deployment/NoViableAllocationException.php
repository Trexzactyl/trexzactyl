<?php

namespace Trexz\Exceptions\Service\Deployment;

use Trexz\Exceptions\DisplayException;

class NoViableAllocationException extends DisplayException
{
}
