<?php

namespace Trexz\Exceptions\Service\Deployment;

use Trexz\Exceptions\DisplayException;

class NoViableNodeException extends DisplayException
{
}
