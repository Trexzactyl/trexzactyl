<?php

namespace Trexz\Exceptions\Service\Helper;

class CdnVersionFetchingException extends \Exception
{
}
