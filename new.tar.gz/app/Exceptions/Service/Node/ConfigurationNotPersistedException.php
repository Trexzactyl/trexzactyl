<?php

namespace Trexz\Exceptions\Service\Node;

use Trexz\Exceptions\DisplayException;

class ConfigurationNotPersistedException extends DisplayException
{
}
