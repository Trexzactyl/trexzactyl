<?php

namespace Trexz\Exceptions\Service\Server;

use Trexz\Exceptions\PterodactylException;

class RequiredVariableMissingException extends PterodactylException
{
}
