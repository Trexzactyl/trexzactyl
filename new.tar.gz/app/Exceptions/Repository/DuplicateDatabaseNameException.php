<?php

namespace Trexz\Exceptions\Repository;

use Trexz\Exceptions\DisplayException;

class DuplicateDatabaseNameException extends DisplayException
{
}
