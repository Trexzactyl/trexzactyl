<?php

namespace Trexz\Exceptions\Repository\Daemon;

use Trexz\Exceptions\Repository\RepositoryException;

class InvalidPowerSignalException extends RepositoryException
{
}
