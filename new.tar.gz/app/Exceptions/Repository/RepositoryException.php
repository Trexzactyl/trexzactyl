<?php

namespace Trexz\Exceptions\Repository;

use Trexz\Exceptions\PterodactylException;

class RepositoryException extends PterodactylException
{
}
