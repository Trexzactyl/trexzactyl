<?php

namespace Trexz\Exceptions\Http\Base;

use Trexz\Exceptions\DisplayException;

class InvalidPasswordProvidedException extends DisplayException
{
}
