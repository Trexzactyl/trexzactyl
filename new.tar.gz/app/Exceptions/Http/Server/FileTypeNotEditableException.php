<?php

namespace Trexz\Exceptions\Http\Server;

use Trexz\Exceptions\DisplayException;

class FileTypeNotEditableException extends DisplayException
{
}
