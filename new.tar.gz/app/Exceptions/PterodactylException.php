<?php

namespace Trexz\Exceptions;

class PterodactylException extends \Exception
{
}
