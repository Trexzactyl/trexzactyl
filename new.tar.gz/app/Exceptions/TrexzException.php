<?php

namespace Trexz\Exceptions;

class TrexzException extends \Exception
{
}
