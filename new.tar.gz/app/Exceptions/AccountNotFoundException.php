<?php

namespace Trexz\Exceptions;

class AccountNotFoundException extends \Exception
{
}
