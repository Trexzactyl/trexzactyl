<?php

namespace Trexz\Exceptions\Transformer;

use Trexz\Exceptions\TrexzException;

class InvalidTransformerLevelException extends TrexzException
{
}
