<?php

namespace Trexz\Exceptions;

class AutoDeploymentException extends \Exception
{
}
