<?php

namespace Trexz\Contracts\Repository;

interface ServerVariableRepositoryInterface extends RepositoryInterface
{
}
