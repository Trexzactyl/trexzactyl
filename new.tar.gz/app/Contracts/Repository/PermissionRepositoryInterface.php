<?php

namespace Trexz\Contracts\Repository;

interface PermissionRepositoryInterface extends RepositoryInterface
{
}
