<?php

namespace Trexz\Contracts\Repository;

interface ApiPermissionRepositoryInterface extends RepositoryInterface
{
}
