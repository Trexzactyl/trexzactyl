<?php

namespace Trexz\Contracts\Repository;

interface UserRepositoryInterface extends RepositoryInterface
{
}
